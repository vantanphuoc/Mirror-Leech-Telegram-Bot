#!/usr/bin/env python3
from time import sleep
from logging import getLogger
from time import time
from os import path as ospath
from googleapiclient.errors import HttpError
from tenacity import retry, wait_exponential, stop_after_attempt, retry_if_exception_type, RetryError

from bot import config_dict, GLOBAL_EXTENSION_FILTER
from bot.helper.ext_utils.bot_utils import async_to_sync
from bot.helper.mirror_utils.gdrive_utils.helper import GoogleDriveHelper

LOGGER = getLogger(__name__)


class gdClone(GoogleDriveHelper):

    def __init__(self, name, listener):
        self.listener = listener
        super().__init__(listener, name)
        self.is_cloning = True
        self.__start_time = time()

    def clone(self, link, gdrive_id):
        if not gdrive_id:
            gdrive_id = config_dict['GDRIVE_ID']
        try:
            file_id = self.getIdFromUrl(link)
        except (KeyError, IndexError):
            return "Google Drive ID could not be found in the provided link", None, None, None, None
        self.service = self.authorize()
        msg = ""
        LOGGER.info(f"File ID: {file_id}")
        try:
            meta = self.getFileMetadata(file_id)
            mime_type = meta.get("mimeType")
            if mime_type == self.G_DRIVE_DIR_MIME_TYPE:
                dir_id = self.create_directory(meta.get('name'), gdrive_id)
                self.__cloneFolder(meta.get('name'), meta.get('id'), dir_id)
                durl = self.G_DRIVE_DIR_BASE_DOWNLOAD_URL.format(dir_id)
                if self.is_cancelled:
                    LOGGER.info("Deleting cloned data from Drive...")
                    self.service.files().delete(fileId=dir_id, supportsAllDrives=True).execute()
                    LOGGER.info("Successfully deleted cloned data from Drive.")
                    return None, None, None, None, None, None
                mime_type = 'Folder'
                size = self.proc_bytes
            else:
                file = self.__copyFile(meta.get('id'), gdrive_id)
                msg += f'<b>Name: </b><code>{file.get("name")}</code>'
                durl = self.G_DRIVE_BASE_DOWNLOAD_URL.format(file.get("id"))
                if mime_type is None:
                    mime_type = 'File'
                size = int(meta.get('size', 0))
            return durl, size, mime_type, self.total_files, self.total_folders, self.getIdFromUrl(durl)
        except Exception as err:
            if isinstance(err, RetryError):
                LOGGER.info(f"Total Attempts: {err.last_attempt.attempt_number}")
                err = err.last_attempt.exception()
            err = str(err).replace('>', '').replace('<', '')
            if "User rate limit exceeded" in err:
                msg = "User rate limit exceeded."
            elif "File not found" in err:
                if not self.alt_auth and self.use_sa:
                    self.alt_auth = True
                    self.use_sa = False
                    LOGGER.error('File not found. Trying with token.pickle...')
                    return self.clone(link, gdrive_id)
                msg = "File not found."
            else:
                msg = f"Error.\n{err}"
            async_to_sync(self.listener.onUploadError, msg)
            return None, None, None, None, None, None

    def __cloneFolder(self, folder_name, folder_id, dest_id):
        LOGGER.info(f"Syncing: {folder_name}")
        files = self.getFilesByFolderId(folder_id)
        if len(files) == 0:
            return dest_id
        for file in files:
            if file.get("mimeType") == self.G_DRIVE_DIR_MIME_TYPE:
                self.total_folders += 1
                file_path = ospath.join(folder_name, file.get("name"))
                current_dir_id = self.create_directory(file.get("name"), dest_id)
                self.__cloneFolder(file_path, file.get("id"), current_dir_id)
            elif not file.get("name").lower().endswith(tuple(GLOBAL_EXTENSION_FILTER)):
                self.total_files += 1
                self.__copyFile(file.get("id"), dest_id)
                self.proc_bytes += int(file.get("size", 0))
                self.total_time = int(time() - self.__start_time)
            if self.is_cancelled:
                break

    @retry(wait=wait_exponential(multiplier=2, min=3, max=6), stop=stop_after_attempt(3),
           retry=retry_if_exception_type(Exception))
    def __copyFile(self, file_id, dest_id):
        body = {'parents': [dest_id]}
        try:
            return self.service.files().copy(fileId=file_id, body=body, supportsAllDrives=True).execute()
        except HttpError as err:
            if err.resp.get('content-type', '').startswith('application/json'):
                reason = eval(err.content).get('error').get('errors')[0].get('reason')
                if reason not in ['userRateLimitExceeded', 'dailyLimitExceeded', 'cannotCopyFile']:
                    raise err
                if reason == 'cannotCopyFile':
                    LOGGER.error(err)
                elif config_dict['USE_SERVICE_ACCOUNTS']:
                    if reason == 'userRateLimitExceeded':
                        sleep(30)
                    if self.sa_count >= self.sa_number:
                        LOGGER.info(f"Reached maximum number of service accounts switching, which is {self.sa_count}")
                        raise err
                    else:
                        if self.is_cancelled:
                            return
                        self.switchServiceAccount()
                        return self.__copyFile(file_id, dest_id)
                else:
                    LOGGER.error(f"Got: {reason}")
                    raise err
